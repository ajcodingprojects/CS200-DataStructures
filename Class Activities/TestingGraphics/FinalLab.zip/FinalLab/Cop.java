/**
 * Subclass of PeopleEntities
 * 
 */

import java.io.*;
import java.util.*;

/**
 * Grant Peroutka and Andrew Nerud
 */
public class Cop extends PeopleEntities {
  
  /**
   * Default constructor for a cop object
   */
  public Cop() {
    super();
  }
  
}